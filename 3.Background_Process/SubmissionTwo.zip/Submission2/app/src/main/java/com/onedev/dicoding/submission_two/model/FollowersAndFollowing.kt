package com.onedev.dicoding.submission_two.model

class FollowersAndFollowing : ArrayList<ItemFollowersAndFollowingItem>()