package com.onedev.dicoding.submission_two.model

data class ItemFollowersAndFollowingItem(
    val avatar_url: String,
    val login: String
)