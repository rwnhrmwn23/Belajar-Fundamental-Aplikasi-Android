package com.onedev.dicoding.submission_two.util

class Constant {
    companion object {
        const val KEY_PREFERENCE_NAME = "DICODING.SUBMISSION.TWO"
        const val USERNAME = "username"
    }
}